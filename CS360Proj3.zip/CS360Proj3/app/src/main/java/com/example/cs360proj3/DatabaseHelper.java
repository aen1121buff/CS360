package com.example.cs360proj3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "cs360proj3.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";
    public static final String COL_PHONE = "phone";

    public static final String TABLE_INVENTORY = "inventory_items";
    public static final String COL_ITEM_ID = "id";
    public static final String COL_ITEM_NAME = "item_name";
    public static final String COL_ITEM_QTY = "quantity";
    public static final String COL_ITEM_DATE = "date_text";
    public static final String COL_ITEM_OWNER = "owner_username";

    public static final String TABLE_SMS_SETTINGS = "sms_settings";
    public static final String COL_SMS_ID = "id";
    public static final String COL_SMS_OWNER = "owner_username";
    public static final String COL_SMS_PHONE = "phone";
    public static final String COL_SMS_THRESHOLD = "threshold_qty";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsers = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT UNIQUE, " +
                COL_PASSWORD + " TEXT, " +
                COL_PHONE + " TEXT" +
                ")";

        String createInventory = "CREATE TABLE " + TABLE_INVENTORY + " (" +
                COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_ITEM_NAME + " TEXT, " +
                COL_ITEM_QTY + " INTEGER, " +
                COL_ITEM_DATE + " TEXT, " +
                COL_ITEM_OWNER + " TEXT" +
                ")";

        String createSmsSettings = "CREATE TABLE " + TABLE_SMS_SETTINGS + " (" +
                COL_SMS_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_SMS_OWNER + " TEXT UNIQUE, " +
                COL_SMS_PHONE + " TEXT, " +
                COL_SMS_THRESHOLD + " INTEGER DEFAULT 5" +
                ")";

        db.execSQL(createUsers);
        db.execSQL(createInventory);
        db.execSQL(createSmsSettings);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SMS_SETTINGS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // User methods

    public boolean createUser(String username, String password, String phone) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);
        values.put(COL_PHONE, phone);

        long result = db.insert(TABLE_USERS, null, values);

        if (result == -1) {
            return false;
        }

        // Create default SMS settings row for the user
        ContentValues smsValues = new ContentValues();
        smsValues.put(COL_SMS_OWNER, username);
        smsValues.put(COL_SMS_PHONE, phone);
        smsValues.put(COL_SMS_THRESHOLD, 5);
        db.insert(TABLE_SMS_SETTINGS, null, smsValues);

        return true;
    }

    public boolean validateLogin(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS + " WHERE " + COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password}
        );

        boolean valid = cursor.moveToFirst();
        cursor.close();
        return valid;
    }

    public String getUserPhone(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT " + COL_PHONE + " FROM " + TABLE_USERS + " WHERE " + COL_USERNAME + "=?",
                new String[]{username}
        );

        String phone = "";
        if (cursor.moveToFirst()) {
            int idx = cursor.getColumnIndex(COL_PHONE);
            if (idx >= 0 && cursor.getString(idx) != null) {
                phone = cursor.getString(idx);
            }
        }
        cursor.close();
        return phone;
    }

    // Inventory CRUD methods

    public boolean addInventoryItem(String ownerUsername, String itemName, int quantity, String dateText) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_ITEM_OWNER, ownerUsername);
        values.put(COL_ITEM_NAME, itemName);
        values.put(COL_ITEM_QTY, quantity);
        values.put(COL_ITEM_DATE, dateText);

        long result = db.insert(TABLE_INVENTORY, null, values);
        return result != -1;
    }

    public ArrayList<InventoryItem> getAllInventoryItems(String ownerUsername) {
        ArrayList<InventoryItem> items = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_INVENTORY + " WHERE " + COL_ITEM_OWNER + "=? ORDER BY " + COL_ITEM_ID + " DESC",
                new String[]{ownerUsername}
        );

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ITEM_ID));
                String itemName = cursor.getString(cursor.getColumnIndexOrThrow(COL_ITEM_NAME));
                int qty = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ITEM_QTY));
                String dateText = cursor.getString(cursor.getColumnIndexOrThrow(COL_ITEM_DATE));

                items.add(new InventoryItem(id, itemName, qty, dateText));
            } while (cursor.moveToNext());
        }

        cursor.close();
        return items;
    }

    public boolean updateInventoryItemByName(String ownerUsername, String existingItemName, int newQuantity, String newDate) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_ITEM_QTY, newQuantity);
        values.put(COL_ITEM_DATE, newDate);

        int rows = db.update(
                TABLE_INVENTORY,
                values,
                COL_ITEM_OWNER + "=? AND " + COL_ITEM_NAME + "=?",
                new String[]{ownerUsername, existingItemName}
        );

        return rows > 0;
    }

    public boolean deleteInventoryItemById(int itemId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_INVENTORY, COL_ITEM_ID + "=?", new String[]{String.valueOf(itemId)});
        return rows > 0;
    }

    // SMS settings methods

    public boolean saveSmsSettings(String ownerUsername, String phone, int threshold) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_SMS_PHONE, phone);
        values.put(COL_SMS_THRESHOLD, threshold);

        int updated = db.update(
                TABLE_SMS_SETTINGS,
                values,
                COL_SMS_OWNER + "=?",
                new String[]{ownerUsername}
        );

        if (updated == 0) {
            ContentValues insertValues = new ContentValues();
            insertValues.put(COL_SMS_OWNER, ownerUsername);
            insertValues.put(COL_SMS_PHONE, phone);
            insertValues.put(COL_SMS_THRESHOLD, threshold);
            long result = db.insert(TABLE_SMS_SETTINGS, null, insertValues);
            return result != -1;
        }

        return true;
    }

    public String getSmsPhoneForUser(String ownerUsername) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + COL_SMS_PHONE + " FROM " + TABLE_SMS_SETTINGS + " WHERE " + COL_SMS_OWNER + "=?",
                new String[]{ownerUsername}
        );

        String phone = "";
        if (cursor.moveToFirst()) {
            int idx = cursor.getColumnIndex(COL_SMS_PHONE);
            if (idx >= 0 && cursor.getString(idx) != null) {
                phone = cursor.getString(idx);
            }
        }

        cursor.close();
        return phone;
    }

    public int getSmsThresholdForUser(String ownerUsername) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + COL_SMS_THRESHOLD + " FROM " + TABLE_SMS_SETTINGS + " WHERE " + COL_SMS_OWNER + "=?",
                new String[]{ownerUsername}
        );

        int threshold = 5;
        if (cursor.moveToFirst()) {
            int idx = cursor.getColumnIndex(COL_SMS_THRESHOLD);
            if (idx >= 0) {
                threshold = cursor.getInt(idx);
            }
        }

        cursor.close();
        return threshold;
    }
}
