package com.example.cs360proj3;

public class InventoryItem {
    private int id;
    private String itemName;
    private int quantity;
    private String dateText;

    public InventoryItem(int id, String itemName, int quantity, String dateText) {
        this.id = id;
        this.itemName = itemName;
        this.quantity = quantity;
        this.dateText = dateText;
    }

    public int getId() {
        return id;
    }

    public String getItemName() {
        return itemName;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getDateText() {
        return dateText;
    }
}
