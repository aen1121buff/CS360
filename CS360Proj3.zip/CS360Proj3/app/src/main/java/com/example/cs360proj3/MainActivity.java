package com.example.cs360proj3;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editUsername;
    private EditText editPassword;
    private EditText editPhone;
    private Button buttonLogin;
    private Button buttonCreateAccount;
    private TextView textLoginStatus;

    private DatabaseHelper databaseHelper;

    public static final String PREFS_NAME = "CS360Prefs";
    public static final String KEY_LOGGED_IN_USER = "loggedInUser";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        editPhone = findViewById(R.id.editPhone);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);
        textLoginStatus = findViewById(R.id.textLoginStatus);

        buttonCreateAccount.setOnClickListener(v -> createAccount());
        buttonLogin.setOnClickListener(v -> loginUser());
    }

    private void createAccount() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString().trim();
        String phone = editPhone.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            textLoginStatus.setText("Username and password are required.");
            return;
        }

        boolean created = databaseHelper.createUser(username, password, phone);

        if (created) {
            textLoginStatus.setText("Account created successfully. You can now log in.");
            Toast.makeText(this, "Account created", Toast.LENGTH_SHORT).show();
        } else {
            textLoginStatus.setText("Account creation failed. Username may already exist.");
            Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
        }
    }

    private void loginUser() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            textLoginStatus.setText("Please enter username and password.");
            return;
        }

        boolean valid = databaseHelper.validateLogin(username, password);

        if (valid) {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            prefs.edit().putString(KEY_LOGGED_IN_USER, username).apply();

            textLoginStatus.setText("Login successful.");
            Toast.makeText(this, "Welcome " + username, Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(MainActivity.this, DataGridActivity.class);
            startActivity(intent);
        } else {
            textLoginStatus.setText("Login failed. Invalid username or password.");
            Toast.makeText(this, "Invalid login", Toast.LENGTH_SHORT).show();
        }
    }
}