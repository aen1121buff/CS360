package com.example.cs360proj3;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DataGridActivity extends AppCompatActivity {

    private RecyclerView recyclerGrid;
    private TextView textWelcome;

    private EditText editItemName;
    private EditText editQuantity;
    private EditText editDate;
    private Button buttonAddRow;

    private EditText editUpdateItemName;
    private EditText editUpdateQuantity;
    private EditText editUpdateDate;
    private Button buttonUpdateRow;

    private Button buttonSmsSettings;

    private DatabaseHelper databaseHelper;
    private InventoryAdapter inventoryAdapter;
    private ArrayList<InventoryItem> inventoryList;

    private String currentUsername = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_grid);

        databaseHelper = new DatabaseHelper(this);

        SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS_NAME, MODE_PRIVATE);
        currentUsername = prefs.getString(MainActivity.KEY_LOGGED_IN_USER, "");

        if (currentUsername == null || currentUsername.isEmpty()) {
            Toast.makeText(this, "No user logged in. Returning to login screen.", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        recyclerGrid = findViewById(R.id.recyclerGrid);
        textWelcome = findViewById(R.id.textWelcome);

        editItemName = findViewById(R.id.editItemName);
        editQuantity = findViewById(R.id.editQuantity);
        editDate = findViewById(R.id.editDate);
        buttonAddRow = findViewById(R.id.buttonAddRow);

        editUpdateItemName = findViewById(R.id.editUpdateItemName);
        editUpdateQuantity = findViewById(R.id.editUpdateQuantity);
        editUpdateDate = findViewById(R.id.editUpdateDate);
        buttonUpdateRow = findViewById(R.id.buttonUpdateRow);

        buttonSmsSettings = findViewById(R.id.buttonSmsSettings);

        textWelcome.setText("Welcome, " + currentUsername);

        recyclerGrid.setLayoutManager(new LinearLayoutManager(this));
        inventoryList = new ArrayList<>();
        inventoryAdapter = new InventoryAdapter(inventoryList, this::deleteItem);
        recyclerGrid.setAdapter(inventoryAdapter);

        buttonAddRow.setOnClickListener(v -> addItem());
        buttonUpdateRow.setOnClickListener(v -> updateItem());
        buttonSmsSettings.setOnClickListener(v ->
                startActivity(new Intent(DataGridActivity.this, SmsActivity.class)));

        loadInventoryData();
    }

    private void loadInventoryData() {
        inventoryList = databaseHelper.getAllInventoryItems(currentUsername);
        inventoryAdapter.setItemList(inventoryList);
    }

    private void addItem() {
        String itemName = editItemName.getText().toString().trim();
        String qtyText = editQuantity.getText().toString().trim();
        String dateText = editDate.getText().toString().trim();

        if (itemName.isEmpty() || qtyText.isEmpty() || dateText.isEmpty()) {
            Toast.makeText(this, "Please fill item name, quantity, and date.", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(qtyText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Quantity must be a number.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean success = databaseHelper.addInventoryItem(currentUsername, itemName, quantity, dateText);

        if (success) {
            Toast.makeText(this, "Item added.", Toast.LENGTH_SHORT).show();

            editItemName.setText("");
            editQuantity.setText("");
            editDate.setText("");

            loadInventoryData();
            checkAndSendLowInventoryAlert(itemName, quantity);
        } else {
            Toast.makeText(this, "Failed to add item.", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateItem() {
        String existingItemName = editUpdateItemName.getText().toString().trim();
        String qtyText = editUpdateQuantity.getText().toString().trim();
        String dateText = editUpdateDate.getText().toString().trim();

        if (existingItemName.isEmpty() || qtyText.isEmpty() || dateText.isEmpty()) {
            Toast.makeText(this, "Fill all update fields.", Toast.LENGTH_SHORT).show();
            return;
        }

        int newQty;
        try {
            newQty = Integer.parseInt(qtyText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "New quantity must be a number.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean updated = databaseHelper.updateInventoryItemByName(currentUsername, existingItemName, newQty, dateText);

        if (updated) {
            Toast.makeText(this, "Item updated.", Toast.LENGTH_SHORT).show();

            editUpdateItemName.setText("");
            editUpdateQuantity.setText("");
            editUpdateDate.setText("");

            loadInventoryData();
            checkAndSendLowInventoryAlert(existingItemName, newQty);
        } else {
            Toast.makeText(this, "No matching item found to update.", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteItem(InventoryItem item) {
        boolean deleted = databaseHelper.deleteInventoryItemById(item.getId());

        if (deleted) {
            Toast.makeText(this, "Item deleted.", Toast.LENGTH_SHORT).show();
            loadInventoryData();
        } else {
            Toast.makeText(this, "Delete failed.", Toast.LENGTH_SHORT).show();
        }
    }

    private void checkAndSendLowInventoryAlert(String itemName, int quantity) {
        int threshold = databaseHelper.getSmsThresholdForUser(currentUsername);

        if (quantity > threshold) {
            return;
        }

        String phone = databaseHelper.getSmsPhoneForUser(currentUsername);
        if (phone == null || phone.trim().isEmpty()) {
            Toast.makeText(this, "Low inventory detected, but no SMS phone is saved.", Toast.LENGTH_LONG).show();
            return;
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Low inventory detected. SMS permission not granted.", Toast.LENGTH_LONG).show();
            return;
        }

        String message = "Low inventory alert: " + itemName + " is at quantity " + quantity + ".";

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phone, null, message, null, null);
            Toast.makeText(this, "Low inventory SMS alert sent.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Could not send SMS on this device/emulator.", Toast.LENGTH_LONG).show();
        }
    }
}
