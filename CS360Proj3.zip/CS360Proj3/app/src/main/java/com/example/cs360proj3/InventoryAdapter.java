package com.example.cs360proj3;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ItemViewHolder> {

    public interface OnDeleteClickListener {
        void onDeleteClick(InventoryItem item);
    }

    private ArrayList<InventoryItem> itemList;
    private final OnDeleteClickListener deleteClickListener;

    public InventoryAdapter(ArrayList<InventoryItem> itemList, OnDeleteClickListener deleteClickListener) {
        this.itemList = itemList;
        this.deleteClickListener = deleteClickListener;
    }

    public void setItemList(ArrayList<InventoryItem> itemList) {
        this.itemList = itemList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_item, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        InventoryItem item = itemList.get(position);

        holder.textItem.setText(item.getItemName());
        holder.textQty.setText(String.valueOf(item.getQuantity()));
        holder.textDate.setText(item.getDateText());

        holder.buttonDelete.setOnClickListener(v -> {
            if (deleteClickListener != null) {
                deleteClickListener.onDeleteClick(item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return itemList == null ? 0 : itemList.size();
    }

    static class ItemViewHolder extends RecyclerView.ViewHolder {
        TextView textItem;
        TextView textQty;
        TextView textDate;
        Button buttonDelete;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            textItem = itemView.findViewById(R.id.textItem);
            textQty = itemView.findViewById(R.id.textQty);
            textDate = itemView.findViewById(R.id.textDate);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }
}
