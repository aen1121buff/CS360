package com.example.cs360proj3;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SmsActivity extends AppCompatActivity {

    private TextView textSmsStatus;
    private TextView textUserResponse;
    private Button buttonSendTestSms;
    private Button buttonCheckPermission;
    private Button buttonRequestPermission;
    private Button buttonSaveSmsSettings;

    private EditText editSmsPhone;
    private EditText editSmsThreshold;

    private DatabaseHelper databaseHelper;
    private String currentUsername = "";

    private final ActivityResultLauncher<String> requestSmsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) {
                    textSmsStatus.setText("Permission status: GRANTED");
                    textUserResponse.setText("User response: Permission granted. SMS alerts can be used.");
                    buttonSendTestSms.setEnabled(true);
                } else {
                    textSmsStatus.setText("Permission status: DENIED");
                    textUserResponse.setText("User response: Permission denied. App will continue without SMS alerts.");
                    buttonSendTestSms.setEnabled(false);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        databaseHelper = new DatabaseHelper(this);

        SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS_NAME, MODE_PRIVATE);
        currentUsername = prefs.getString(MainActivity.KEY_LOGGED_IN_USER, "");

        textSmsStatus = findViewById(R.id.textSmsStatus);
        textUserResponse = findViewById(R.id.textUserResponse);
        buttonSendTestSms = findViewById(R.id.buttonSendTestSms);
        buttonCheckPermission = findViewById(R.id.buttonCheckPermission);
        buttonRequestPermission = findViewById(R.id.buttonRequestPermission);
        buttonSaveSmsSettings = findViewById(R.id.buttonSaveSmsSettings);

        editSmsPhone = findViewById(R.id.editSmsPhone);
        editSmsThreshold = findViewById(R.id.editSmsThreshold);

        loadSavedSmsSettings();

        buttonCheckPermission.setOnClickListener(v -> updatePermissionUI());

        buttonRequestPermission.setOnClickListener(v -> {
            if (!hasSmsPermission()) {
                requestSmsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
            } else {
                textSmsStatus.setText("Permission status: GRANTED");
                textUserResponse.setText("User response: Already granted.");
                buttonSendTestSms.setEnabled(true);
            }
        });

        buttonSaveSmsSettings.setOnClickListener(v -> saveSmsSettings());

        buttonSendTestSms.setOnClickListener(v -> sendTestSms());

        updatePermissionUI();
    }

    private void loadSavedSmsSettings() {
        if (currentUsername == null || currentUsername.isEmpty()) {
            return;
        }

        String phone = databaseHelper.getSmsPhoneForUser(currentUsername);
        int threshold = databaseHelper.getSmsThresholdForUser(currentUsername);

        if (phone != null) {
            editSmsPhone.setText(phone);
        }
        editSmsThreshold.setText(String.valueOf(threshold));
    }

    private void saveSmsSettings() {
        if (currentUsername == null || currentUsername.isEmpty()) {
            Toast.makeText(this, "No logged in user found.", Toast.LENGTH_SHORT).show();
            return;
        }

        String phone = editSmsPhone.getText().toString().trim();
        String thresholdText = editSmsThreshold.getText().toString().trim();

        int threshold = 5;
        if (!thresholdText.isEmpty()) {
            try {
                threshold = Integer.parseInt(thresholdText);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Threshold must be a number.", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        boolean saved = databaseHelper.saveSmsSettings(currentUsername, phone, threshold);

        if (saved) {
            Toast.makeText(this, "SMS settings saved.", Toast.LENGTH_SHORT).show();
            textUserResponse.setText("SMS settings saved for " + currentUsername + ".");
        } else {
            Toast.makeText(this, "Failed to save SMS settings.", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendTestSms() {
        if (!hasSmsPermission()) {
            textUserResponse.setText("No permission. Request SMS permission first.");
            buttonSendTestSms.setEnabled(false);
            return;
        }

        String phone = editSmsPhone.getText().toString().trim();
        if (phone.isEmpty()) {
            textUserResponse.setText("Enter a phone number first, then try again.");
            return;
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phone, null, "Test SMS from CS360Proj3 inventory app.", null, null);
            textUserResponse.setText("Test SMS send requested.");
            Toast.makeText(this, "Test SMS sent (or attempted).", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            textUserResponse.setText("Could not send test SMS on this device/emulator.");
            Toast.makeText(this, "SMS send failed on emulator/device.", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void updatePermissionUI() {
        if (hasSmsPermission()) {
            textSmsStatus.setText("Permission status: GRANTED");
            textUserResponse.setText("SMS alerts are available.");
            buttonSendTestSms.setEnabled(true);
        } else {
            textSmsStatus.setText("Permission status: NOT GRANTED");
            textUserResponse.setText("SMS alerts are disabled until permission is granted.");
            buttonSendTestSms.setEnabled(false);
        }
    }
}
